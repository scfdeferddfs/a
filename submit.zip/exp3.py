from copy import deepcopy
import pandas as pd
import pickle
import json
from utils import *

with open('e11_list.json', 'r') as f:
    e11_list = json.load(f)
summary = pd.read_csv('UCRArchive_2018/DataSummary.csv')

### parameters
n_jobs = 5
verbose = True
shift_list = [round(i/100, 2) for i in range(0, 31, 3)]
shift_list = [0.15] # please remove this line to get all results
algorithms = ['dtw', 'dtwb', 'psi_dtw', 'dtwj', 'dtwja']

all_result = {}
for shift in shift_list:
    print(f'------shift:{shift}---------')
    result1 = experiment(size=1e20, r=0.05, train=False, mode=0, shift=shift, verbose=verbose, algorithms=['dtw', 'dtwb', 'psi_dtw'], dataset_list=e11_list, n_jobs=n_jobs)
    result2 = experiment(size=1e20, r=0.15, train=False, mode=0, shift=shift, verbose=verbose, algorithms=['dtwj', 'dtwja'], dataset_list=e11_list, n_jobs=n_jobs)
    result = deepcopy(result1)
    result['test_error_dtwj'] = result2['test_error_dtwj']
    result['test_error_dtwja'] = result2['test_error_dtwja']
    all_result[shift] = result
    show_result(result, summary, algorithms=algorithms, show_default=False)
    with open("result/1e11_shift_0_30.pkl", 'wb') as f:
        pickle.dump(all_result, f)