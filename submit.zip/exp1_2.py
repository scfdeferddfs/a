from copy import deepcopy
import pandas as pd
import pickle
import json
from utils import *

with open('e11_list.json', 'r') as f:
    e11_list = json.load(f)
summary = pd.read_csv('UCRArchive_2018/DataSummary.csv')

### parameters
n_jobs = 10

all_result = {}

algorithms = ['dtw', 'dtwb', 'psi_dtw']
r = 0.05
print(f'------relative_r:{r}---------')
result = experiment(size=1e20, r=r, train=True, mode=0, verbose=False, algorithms=algorithms, dataset_list=e11_list, n_jobs=n_jobs)
all_result[r] = result
show_result(result, summary, algorithms=algorithms, show_default=False)

algorithms = ['dtwj', 'dtwja']
r = 0.15
print(f'------relative_r:{r}---------')
result = experiment(size=1e20, r=r, train=True, mode=0, verbose=False, algorithms=algorithms, dataset_list=e11_list, n_jobs=n_jobs)
all_result[r] = result
show_result(result, summary, algorithms=algorithms, show_default=False)
with open("result/texas_1e11.pkl", 'wb') as f:
    pickle.dump(all_result, f)