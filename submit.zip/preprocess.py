from utils import *
import json

e11_list = []
size = 1e11
for directory in sorted(glob('UCRArchive_2018/*')):
    name = directory.split('/')[-1]
#     if dataset and name not in dataset:
#         continue
    if 'csv' in name or 'xlsx' in name or name == 'Missing_value_and_variable_length_datasets_adjusted':
        continue
    print(f'-------{name}--------')
    for path in glob(f'{directory}/*'):
        if 'TRAIN.tsv' in path:  
            train_path = path
        elif 'TEST.tsv' in path:
            test_path = path

    train_data = preprocess2(train_path)
    test_data = preprocess2(test_path)
    train_len = [len(x) for x in train_data]
    test_len = [len(x) for x in test_data]
    train_avg_len = round(np.mean(train_len),1)
    train_max_len = np.max(train_len)
    test_avg_len = round(np.mean(test_len),1)
    test_max_len = np.max(test_len)

    multiply_size = len(train_data) * train_avg_len * len(test_data) * test_avg_len
    if multiply_size <= size and train_avg_len == test_avg_len and not isinstance(train_data, list) and not  isinstance(test_data, list):
        e11_list.append(name)
    else:
        print(f'drop:{name}')
        
print(f'There are {len(e11_list)} datasets')        
with open('e11_list.json', 'w') as f:
    json.dump(e11_list, f)