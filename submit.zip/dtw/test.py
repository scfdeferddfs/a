from _dtw import dtw
import numpy as np

data = np.cumsum(np.random.uniform(-0.5, 0.5, 100))
query = np.cumsum(np.random.uniform(-0.5, 0.5, 100))

r = 0.0
dist_dtw = dtw(data, query, r, "dtw")
dist_dtwb = dtw(data, query, r, "dtwb")
dist_psi_dtw = dtw(data, query, r, "psi_dtw")

# To be consistent, we minimize the negative of similarity (which is equal to maximize similarity)
dist_dtwj = dtw(data, query, r, "dtwj") 
dist_dtwja = dtw(data, query, r, "dtwja")

print(f'r={r}')
print(f'dtw:{dist_dtw}')
print(f'dtwb:{dist_dtwb}')
print(f'psi_dtw:{dist_psi_dtw}')
print(f'dtwj:{dist_dtwj}')
print(f'dtwja:{dist_dtwja}')

r = 0.05
dist_dtw = dtw(data, query, r, "dtw")
dist_dtwb = dtw(data, query, r, "dtwb")
dist_psi_dtw = dtw(data, query, r, "psi_dtw")

# To be consistent, we minimize the negative of similarity (which is equal to maximize similarity)
dist_dtwj = dtw(data, query, r, "dtwj") 
dist_dtwja = dtw(data, query, r, "dtwja")

print(f'r={r}')
print(f'dtw:{dist_dtw}')
print(f'dtwb:{dist_dtwb}')
print(f'psi_dtw:{dist_psi_dtw}')
print(f'dtwj:{dist_dtwj}')
print(f'dtwja:{dist_dtwja}')