
double dtw(double* A, double* B, int m, int n, double warp_width);

double dtwb(double* A, double* B, int m, int n, double warp_width);
    
double psi_dtw(double* A, double* B, int m, int n, double warp_width);

double dtwj(double* A, double* B, int m, int n, double warp_width);

double dtwja(double* A, double* B, int m, int n, double warp_width);
