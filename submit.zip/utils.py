import random
from copy import deepcopy
import pandas as pd
from _dtw import dtw
import numpy as np
import matplotlib.pyplot as plt
from glob import glob
from time import time
from collections import Counter
import warnings
warnings.filterwarnings("ignore")
from multiprocessing import Pool
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import scale
import pickle
from scipy import interpolate
import math

def get_mean(error, size):
    return round(error.mean(),3)
def show_result(result, summary, algorithms=[], show_default=False):
    
    for alg in algorithms:
        mean = get_mean(result[f'test_error_{alg}'], result['test'])
        print(f'{alg}:{mean}')
        
    if show_default:
        part_summary = summary[summary['Name'].isin(result.index)]
        part_summary.index = part_summary['Name']
        part_summary = part_summary.loc[result.index]
        assert list(part_summary['Name']) == list(result.index)
        part_summary['DTW (learned_w) '] = part_summary['DTW (learned_w) '].map(lambda x:float(x.split('(')[0]))
        ED_w_0_mean = get_mean(part_summary['ED (w=0)'], result['test'])
        DTW_learned_w_mean = get_mean(part_summary['DTW (learned_w) '], result['test'])
        DTW_w_100_mean = get_mean(part_summary['DTW (w=100)'], result['test'])
        
        print(f'ED_w_0_mean:{ED_w_0_mean}')
        print(f'DTW_learned_w_mean:{DTW_learned_w_mean} ')
        print(f'DTW_w_100_mean:{DTW_w_100_mean}')
def preprocess(path):
    data = np.loadtxt(path)
    data, label = data[:,1:], data[:,0]
    data = scale(data, axis=1)
    counter = Counter(label)
    most_label = max(counter, key=counter.get)
    dic = {'data':data, 'label':label, 'most_label':most_label}
    with open(path[:-4]+'.pkl', 'wb') as file:
        pickle.dump(dic, file)
def preprocess2(path):
    data = np.loadtxt(path)
    data, label = data[:,1:], data[:,0]

    data_new = []
    for series in data:
        for st in range(0, len(series), 1):
            if not np.isnan(series[st]):
                break
        for ed in range(len(series)-1, 0, -1):
            if not np.isnan(series[ed]):
                break
        if st <= ed:
            data_new.append(scale(series[st:ed+1]))
        else:
            data_new.append([])
    if len(set([len(x) for x in data_new])) == 1:
        data_new = np.array(data_new)
    counter = Counter(label)
    most_label = max(counter, key=counter.get)
    dic = {'data':data_new, 'label':label, 'most_label':most_label}
    with open(path[:-4]+'.pkl', 'wb') as file:
        pickle.dump(dic, file)
    return data_new
def get_sample(x, ratio):
    random_indices = random.sample(range(len(x)), int(len(x)*ratio))
    return x[sorted(random_indices)]
def newRW(size, length, minV, maxV, referenceValue):
    rw = np.random.rand(size, length) - 0.5   
    rw[:,0] = rw[:,0] + referenceValue    
    for i in range(1, length):     
        nextVal = rw[:,i-1] + rw[:,i] # rw[:,i] + rw[:,i-1]
        temp = rw[:,i-1] - rw[:,i]    # rw[:,i] - rw[:,i-1]   
        nextVal = [y if x > maxV_ or x < minV_ else x for x,y,maxV_,minV_ in zip(nextVal, temp, maxV, minV)]
        rw[:,i] = nextVal
    return rw
def addRW(data, ratioRW=0, direction=0):
    if ratioRW == 0:
        return data

    minV = data.min(axis=1)
    maxV = data.max(axis=1)
    
    if direction == 0:
        RWLen = math.ceil(ratioRW * len(data[0]) / 2)

        preTS = newRW(len(data), RWLen, minV, maxV, data[:,0])[:,::-1]
        postTS = newRW(len(data), RWLen, minV, maxV, data[:,-1])

        RWdata = np.concatenate([preTS, data, postTS], axis=1)
    elif direction == 1:
        RWLen = math.ceil(ratioRW * len(data[0]))

        preTS = newRW(len(data), RWLen, minV, maxV, data[:,0])[:,::-1]

        RWdata = np.concatenate([preTS, data], axis=1)
    elif direction == -1:
        RWLen = math.ceil(ratioRW * len(data[0]))

        postTS = newRW(len(data), RWLen, minV, maxV, data[:,-1])

        RWdata = np.concatenate([data, postTS], axis=1)
    
    return scale(RWdata, axis=1)
def process(data, noise=0, shift=0, direction=0, drop=0, interp=0):
    if noise > 0:
        gaussian_noise = np.random.normal(loc=0.0, scale=noise, size=data.shape)
        data += gaussian_noise
    if shift > 0:
        data = addRW(data, shift, direction)
    if drop > 0:
        data_new = []
        for i in range(len(data)):
            data_new.append(get_sample(data[i], 1-drop))
        data = np.array(data_new)
    if interp > 0:       
        x = np.arange(0, data.shape[1])
        f = interpolate.interp1d(x, data, axis=1)
        x_new = np.arange(0, data.shape[1]-1, 1/(1+interp))
        data = f(x_new)
    return data
def load_data(path, mode, noise=0, shift=0, direction=0, drop=0, interp=0):
    with open(path, 'rb') as file:
        dic = pickle.load(file)
    if mode == 0:
        pass
    elif mode == 1:
        dic['data'] = scale(dic['data'], axis=1)
    elif mode == 2:
        dic['data'] = np.diff(dic['data'])
        dic['data'] = scale(dic['data'], axis=1)  
    dic['data'] = process(dic['data'], noise, shift, direction, drop, interp)  
    
    return dic['data'], dic['label'], dic['most_label']
def error(label, pred):
    return 1 - accuracy_score(label, pred)
INF = float('inf')
def query(x, algorithm):
    dists = [dtw(train_data_, x, R, algorithm) if not np.array_equal(train_data_,x) else INF for train_data_ in train_data]
    knn_idx = np.argmin(dists)
    pred_label = train_label[knn_idx]
    return pred_label
def query_dtw(x):
    return query(x, 'dtw')
def query_dtwb(x):
    return query(x, 'dtwb')
def query_dtwj(x):
    return query(x, 'dtwj')
def query_dtwja(x):
    return query(x, 'dtwja')
def query_psi_dtw(x):
    return query(x, 'psi_dtw')

import gc
def experiment(size, r, train, mode, verbose, noise=0, shift=0, direction=1, drop=0, interp=0, algorithms=[], dataset_list=[], n_jobs=10):
    global train_data, train_label, R, most_label
    R = r
    
    cnt = 0

    result = pd.DataFrame()
    for directory in sorted(glob('UCRArchive_2018/*')):
        name = directory.split('/')[-1]
        if 'csv' in name or 'xlsx' in name:
            continue
        if dataset_list and name not in dataset_list:
            cnt += 1
            if verbose:
                print('continue')
            continue
        if verbose:
            print(f'-------{name}--------')    
        for path in glob(f'{directory}/*'):
            if 'TRAIN.pkl' in path:  
                train_path = path
            elif 'TEST.pkl' in path:
                test_path = path
        train_data, train_label, most_label = load_data(train_path, mode, noise=noise, shift=shift, direction=direction, drop=drop, interp=0)
        test_data, test_label, _ = load_data(test_path, mode, noise=noise, shift=shift, direction=-direction, drop=0, interp=interp)

        train_len = [len(x) for x in train_data]
        test_len = [len(x) for x in test_data]
        train_avg_len = round(np.mean(train_len),1)
        train_max_len = np.max(train_len)
        test_avg_len = round(np.mean(test_len),1)
        test_max_len = np.max(test_len)

    #     if len(train_data) * train_avg_len * len(test_data) * test_avg_len > 1e10:
#         if train_avg_len != test_avg_len:
#             continue
            
        multiply_size = len(train_data) * train_avg_len * len(test_data) * test_avg_len
        if verbose:
            print(f'train size:{len(train_data)} test size:{len(test_data)}')
            print(f'train length:{len(train_data[0])} test length:{len(test_data[0])}')
            print(f'log10:{np.log10(multiply_size)}')
        if multiply_size > size:
            if verbose:
                print('too large.')
            continue
            
        result.at[name, 'train'] = len(train_data)
        result.at[name, 'test'] = len(test_data)
        result.at[name, 'class'] = len(set(train_label))
        result.at[name, 'train_avg_len'] = train_avg_len
        result.at[name, 'train_max_len'] = train_max_len
        result.at[name, 'test_avg_len'] = test_avg_len
        result.at[name, 'test_max_len'] = test_max_len
            
        if 'dtw' in algorithms:
            start = time()

            p = Pool(n_jobs)
            if train:
                train_pred_dtw = p.map(query_dtw, train_data)
                train_error_dtw = round(error(train_label, train_pred_dtw), 5)
                result.at[name, 'train_error_dtw'] = train_error_dtw
                if verbose:
                    print(f'tr_dtw:{train_error_dtw}')
            test_pred_dtw = p.map(query_dtw, test_data)
            test_error_dtw = round(error(test_label, test_pred_dtw), 5)
            result.at[name, 'test_error_dtw'] = test_error_dtw
            p.close()
            
            dtw_cost = round(time() - start, 3)
            result.at[name, 'dtw_time'] = dtw_cost
            if verbose:
                print(f'te_dtw:{test_error_dtw} cost:{dtw_cost}')
                
        if 'dtwb' in algorithms:
            start = time()

            p = Pool(n_jobs)
            if train:
                train_pred_dtwb = p.map(query_dtwb, train_data)
                train_error_dtwb = round(error(train_label, train_pred_dtwb), 5)
                result.at[name, 'train_error_dtwb'] = train_error_dtwb
                if verbose:
                    print(f'tr_dtwb:{train_error_dtwb}')
            test_pred_dtwb = p.map(query_dtwb, test_data)
            test_error_dtwb = round(error(test_label, test_pred_dtwb), 5)
            result.at[name, 'test_error_dtwb'] = test_error_dtwb
            p.close()
            
            dtwb_cost = round(time() - start, 3)
            result.at[name, 'dtwb_time'] = dtwb_cost
            if verbose:
                print(f'te_dtwb:{test_error_dtwb} cost:{dtwb_cost}')
        
        if 'psi_dtw' in algorithms:
            start = time()

            p = Pool(n_jobs)
            if train:
                train_pred_psi_dtw = p.map(query_psi_dtw, train_data)
                train_error_psi_dtw = round(error(train_label, train_pred_psi_dtw), 5)
                result.at[name, 'train_error_psi_dtw'] = train_error_psi_dtw
                if verbose:
                    print(f'tr_psi_dtw:{train_error_psi_dtw}')
            test_pred_psi_dtw = p.map(query_psi_dtw, test_data)
            test_error_psi_dtw = round(error(test_label, test_pred_psi_dtw), 5)
            result.at[name, 'test_error_psi_dtw'] = test_error_psi_dtw
            p.close()
            
            psi_dtw_cost = round(time() - start, 3)
            result.at[name, 'psi_dtw_time'] = psi_dtw_cost
            if verbose:
                print(f'te_psi_dtw:{test_error_psi_dtw} cost:{psi_dtw_cost}')

        if 'dtwj' in algorithms:
            start = time()

            p = Pool(n_jobs)
            if train:
                train_pred_dtwj = p.map(query_dtwj, train_data)
                train_error_dtwj = round(error(train_label, train_pred_dtwj), 5)
                result.at[name, 'train_error_dtwj'] = train_error_dtwj
                if verbose:
                    print(f'tr_dtwj:{train_error_dtwj}')
            test_pred_dtwj = p.map(query_dtwj, test_data)
            test_error_dtwj = round(error(test_label, test_pred_dtwj), 5)
            result.at[name, 'test_error_dtwj'] = test_error_dtwj
            p.close()     
            
            dtwj_cost = round(time() - start, 3)
            result.at[name, 'dtwj_time'] = dtwj_cost
            if verbose:
                print(f'te_dtwj:{test_error_dtwj} cost:{dtwj_cost}')
            
        if 'dtwja' in algorithms:
            start = time()

            p = Pool(n_jobs)
            if train:
                train_pred_dtwja = p.map(query_dtwja, train_data)
                train_error_dtwja = round(error(train_label, train_pred_dtwja), 5)
                result.at[name, 'train_error_dtwja'] = train_error_dtwja
                if verbose:
                    print(f'tr_dtwja:{train_error_dtwja}')
            test_pred_dtwja = p.map(query_dtwja, test_data)
            test_error_dtwja = round(error(test_label, test_pred_dtwja), 5)
            result.at[name, 'test_error_dtwja'] = test_error_dtwja
            p.close()     
            
            dtwja_cost = round(time() - start, 3)
            result.at[name, 'dtwja_time'] = dtwja_cost
            if verbose:
                print(f'te_dtwja:{test_error_dtwja} cost:{dtwja_cost}')
                
        
        gc.collect()

    if 'Missing_value_and_variable_length_datasets_adjusted' in result.index:
        result.drop('Missing_value_and_variable_length_datasets_adjusted', inplace=True)
    return result