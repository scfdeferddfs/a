/***********************************************************************/
/************************* DISCLAIMER **********************************/
/***********************************************************************/
/** This UCR Suite software is copyright protected (c) 2012 by        **/
/** Thanawin Rakthanmanon, Bilson Campana, Abdullah Mueen,            **/
/** Gustavo Batista and Eamonn Keogh.                                 **/
/**                                                                   **/
/** Unless stated otherwise, all software is provided free of charge. **/
/** As well, all software is provided on an "as is" basis without     **/
/** warranty of any kind, express or implied. Under no circumstances  **/
/** and under no legal theory, whether in tort, contract,or otherwise,**/
/** shall Thanawin Rakthanmanon, Bilson Campana, Abdullah Mueen,      **/
/** Gustavo Batista, or Eamonn Keogh be liable to you or to any other **/
/** person for any indirect, special, incidental, or consequential    **/
/** damages of any character including, without limitation, damages   **/
/** for loss of goodwill, work stoppage, computer failure or          **/
/** malfunction, or for any and all other damages or losses.          **/
/**                                                                   **/
/** If you do not agree with these terms, then you you are advised to **/
/** not use this software.                                            **/
/***********************************************************************/
/***********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include "dtw_unequal.h"

#define min(x,y) ((x)<(y)?(x):(y))
#define max(x,y) ((x)>(y)?(x):(y))
// Two distance
#define dist1(x,y) (x-y)*(x-y)
#define dist2(x,y) min((x-y)*(x-y), 1)
// To be consistent, we minimize the negative of similarity (which is equal to maximize similarity)
#define neg_sim1(x,y) -max(1-(x-y)*(x-y), 0)


#define INF 1e20 // Pseudo-infinite number for this code

/// Calculate Dynamic Time Wrapping distance
/// A,B: data and query, respectively
/// r  : size of Sakoe-Chiba warpping band
double dtw(double* A, double* B, int m, int n, double warp_width) {
    double x, y, z, final_dtw, i2j=(double)n/m;
    int r = warp_width <= 1 ? floor(warp_width * min(m,n) + i2j) : floor(warp_width);
    double *cost;
    double *cost_prev;
    double *cost_tmp;
    int i, j, i2, j2;

    cost = (double*) calloc(max(m,n), sizeof(double));
    cost_prev = (double*) calloc(max(m,n), sizeof(double));
    for (j = 0; j < max(m,n); j++) {
        cost[j] = INF;
        cost_prev[j] = INF;
    }
    for (i = 0; i < min(m, n); i++) {
        j2 = floor((i+1)*i2j)-1;
        for (j = max(0, j2 - r); j <= min(n - 1, j2 + r); j++) {
            /// Initialize all row and column
            if ((i == 0) && (j == 0)) {
                cost[j] = dist1(A[0], B[0]);
                continue;
            }
            if(j == max(0, j2 - r) && j > 0){
                cost[j - 1] = INF;
            }

            if (j - 1 < 0) {
                y = INF;
            } else {
                y = cost[j - 1];
            }
            if (i - 1 < 0) {
                x = INF;
            } else {
                x = cost_prev[j];
            }
            if ((i - 1 < 0) || (j - 1 < 0)) {
                z = INF;
            } else {
                z = cost_prev[j - 1];
            }

            cost[j] = min( min( x, y) , z) + dist1(A[i], B[j]);
            final_dtw = cost[j];
        }
        /// Move current array to previous array.     
        cost_tmp = cost;
        cost = cost_prev;
        cost_prev = cost_tmp;
    }
    free(cost);
    free(cost_prev);
    return final_dtw;
}


// Dynamic Time Warping with upper Bound 
// (Only changes the distance function)
double dtwb(double* A, double* B, int m, int n, double warp_width) {
    double x, y, z, final_dtw, i2j=(double)n/m;
    int r = warp_width <= 1 ? floor(warp_width * min(m,n) + i2j) : floor(warp_width);
    double *cost;
    double *cost_prev;
    double *cost_tmp;
    int i, j, i2, j2;

    cost = (double*) calloc(max(m,n), sizeof(double));
    cost_prev = (double*) calloc(max(m,n), sizeof(double));
    for (j = 0; j < max(m,n); j++) {
        cost[j] = INF;
        cost_prev[j] = INF;
    }
    for (i = 0; i < min(m, n); i++) {
        j2 = floor((i+1)*i2j)-1;
        for (j = max(0, j2 - r); j <= min(n - 1, j2 + r); j++) {
            /// Initialize all row and column
            if ((i == 0) && (j == 0)) {
                cost[j] = dist2(A[0], B[0]);
                continue;
            }
            if(j == max(0, j2 - r) && j > 0){
                cost[j - 1] = INF;
            }

            if (j - 1 < 0) {
                y = INF;
            } else {
                y = cost[j - 1];
            }
            if (i - 1 < 0) {
                x = INF;
            } else {
                x = cost_prev[j];
            }
            if ((i - 1 < 0) || (j - 1 < 0)) {
                z = INF;
            } else {
                z = cost_prev[j - 1];
            }

            cost[j] = min( min( x, y) , z) + dist2(A[i], B[j]);
            final_dtw = cost[j];
        }
        /// Move current array to previous array.     
        cost_tmp = cost;
        cost = cost_prev;
        cost_prev = cost_tmp;
    }
    free(cost);
    free(cost_prev);
    return final_dtw;
}


// Our implementation of this paper:
// Diego Furtado Silva, Gustavo Batista, Eamonn Keogh (2016). Prefix and Suffix Invariant Dynamic Time Warping. IEEE ICDM 2016.
double psi_dtw(double* A, double* B, int m, int n, double warp_width) {
    double x, y, z, final_dtw=INF, i2j=(double)n/m;
    int r = warp_width <= 1 ? floor(warp_width * min(m,n) + i2j) : floor(warp_width);
    int i, j, k, i2, j2;

    double **cost = (double **)malloc(sizeof(double *) *(m+1));
    for (i = 0; i < m+1; i++) {
        cost[i] = (double *)malloc(sizeof(double) * (n+1));
        for (j = 0; j < n+1; j++)
        {
            cost[i][j] = INF;
        }
    }
    int relax = r; // We set the relaxation parameter the same as warping window (=5%)
    cost[0][0] = 0;
    for (i = 1; i < min(m+1,relax+1); i++) { 
        cost[i][0] = 0;
    }
    for (j = 1; j < min(n+1,relax+1); j++) { 
        cost[0][j] = 0;
    }
    for (i = 1; i < min(m,n)+1; i++) {
        j2 = floor(i*i2j);
        for (j = max(1, j2 - r); j <= min(n, j2 + r); j++) {
            cost[i][j] = min(min(cost[i-1][j], cost[i][j-1]),cost[i-1][j-1]) + dist1(A[i-1], B[j-1]);
        }
        
    }
    for (i = max(m-relax,0); i <= m; i++) { 
        final_dtw = min(final_dtw, cost[i][n]);
    }
    for (j = max(n-relax,0); j <= n; j++) { 
        final_dtw = min(final_dtw, cost[m][j]);
    }
    for (i = 0; i < m+1; i++) {
        free(cost[i]);
    }
    free(cost);
    return final_dtw;
}


// Ours: Dynamic Time Warping with Jump
double dtwj(double* A, double* B, int m, int n, double warp_width) {
    double x, y, z, min_cost=0, i2j=(double)n/m;
    int r = warp_width <= 1 ? floor(warp_width * min(m,n) + i2j) : floor(warp_width);
    double *cost;
    double *cost_prev;
    double *cost_tmp;
    int i, j, j2;

    cost = (double*) calloc(max(m,n), sizeof(double));
    cost_prev = (double*) calloc(max(m,n), sizeof(double));
    for (j = 0; j < max(m,n); j++) {
        cost[j] = 0;
        cost_prev[j] = 0;
    }
    for (i = 0; i < min(m,n); i++) {
        j2 = floor((i+1)*i2j)-1;
        for (j = max(0, j2 - r); j <= min(n - 1, j2 + r); j++) {

            if (j - 1 < 0) {
                y = 0;
            } else {
                y = cost[j - 1];
            }
            if (i - 1 < 0) {
                x = 0;
            } else {
                x = cost_prev[j];
            }
            if ((i - 1 < 0) && (j - 1 < 0)) {
                z = 0;
            } else {
                z = cost_prev[j - 1];
            }

            cost[j] = min( min( x, y) , z + neg_sim1(A[i], B[j]));
            if (cost[j] < min_cost) {
                min_cost = cost[j];
            }
        }
        /// Move current array to previous array.     
        cost_tmp = cost;
        cost = cost_prev;
        cost_prev = cost_tmp;
    }
    free(cost);
    free(cost_prev);
    return min_cost;
}


// Ours: Dynamic Time Warping with Jump and Aggregate
// Note that in this code, we noly support aggregate two points of the query time series (1v2)
double dtwja(double* A, double* B, int m, int n, double warp_width) {
    double min_cost=0, i2j=(double)n/m;
    int r = warp_width <= 1 ? floor(warp_width * min(m,n) + i2j) : floor(warp_width);
    int i, j, i2, j2, j_, Ki, Kj, K=3;
    
    double **cost = (double **)malloc(sizeof(double *) * K);
    double *cum_A = (double *)malloc(sizeof(double) * (m+1));
    double *cum_B = (double *)malloc(sizeof(double) * (n+1));
    
    for (i = 0; i < K; i++) {
        cost[i] = (double *)malloc(sizeof(double) * (n+1));
        for (j = 0; j < n+1; j++)
        {
            cost[i][j] = 0;
        }
    }
    cum_A[0] = 0;
    cum_B[0] = 0;
    for (i = 1; i < m+1; i++){
        cum_A[i] = cum_A[i-1] + A[i-1];
    }
    for (j = 1; j < n+1; j++){
        cum_B[j] = cum_B[j-1] + B[j-1];
    }
    
    for (i = 1; i < min(m,n)+1; i++) {
        j_ = floor(i*i2j);
        for (j = max(1, j_ - r); j <= min(n, j_ + r); j++) {
            Kj = min(min(K-1, r+1), min(i, j));
            cost[i%K][j] = min(cost[i%K][j-1], cost[(i-1)%K][j]);
            for (j2 = 1; j2 <= Kj; j2++){
                cost[i%K][j] = min(cost[i%K][j], cost[(i-1)%K][j-j2]+neg_sim1(cum_A[i]-cum_A[i-1], (cum_B[j]-cum_B[j-j2])/j2)*(1+j2)); 
            }
            if (cost[i%K][j] < min_cost) {
                min_cost = cost[i%K][j];
            }
        }

    }
    for (i = 0; i < K; i++) {
        free(cost[i]);
    }
    free(cost);
    free(cum_A);
    free(cum_B);
    return min_cost;
}