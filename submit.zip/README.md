### Time Series

The code of time series is modified from https://github.com/klon/ucrdtw.
But we remove all accelerating code and retain the vanilla DTW.

The data of time series is from https://www.cs.ucr.edu/~eamonn/time_series_data_2018/
Thanks for the great work.

The following is the tutorial about how to use our code.
The Python version we used is 3.6.5

Install the requirements
```
pip install -r requirements.txt
```

Compile algorithms
```
cd dtw
python setup.py build && python setup.py install
python test.py # A small example to see the result of five different algorithms
cd ../dtw_unequal
python setup.py build && python setup.py install
python test.py # A small example to see the result when two series have unequal length.
```

Unzip dataset, preprocess, z-normalize and save the data
```
cd ..
unzip UCRArchive_2018.zip # password: someone
python preprocess.py
```

The experiment about changing the size of the warping window.  
Set n_jobs to use multiple cpus.  
Set verbose=True to see the error rate of each dataset.  
Set show_default=True to see the mean error rate of ED (w=0)/DTW (learned_w)/DTW (w=100),
which is from the DataSummary.csv in https://www.cs.ucr.edu/~eamonn/time_series_data_2018/

```
python exp1.py
```

Get the result of both training set and test set to draw Texas SharpShooter plot.
```
python exp1_2.py
```

The experiment about adding Gaussian noise.  

```
python exp2.py
```


The experiment about adding random walk sequence at the beginning and the end.   
We re-implement the random walk in Python version according to:
Diego Furtado Silva, Gustavo Batista, Eamonn Keogh (2016). Prefix and Suffix Invariant Dynamic Time Warping. IEEE ICDM 2016.
https://www.cs.ucr.edu/~eamonn/psi_DTW_10pages.pdf  
https://sites.google.com/site/relaxedboundarydtw/
But our method is different from above work in two aspects:
1. We add random walk sequence at different side of the training and test sequences;
2. We change the code from `nextVal = rw(i) - rw(i-1);` to `addRW.m` to `nextVal = rw(i-1) - rw(i);` in order to get more reasonable random walk sequence.

```
python exp3.py
```


The experiment about random droping the points of training sequences.  

```
python exp4.py # two time series have unequal length
```


The experiment about linear interpolating the points of testing sequences.  

```
python exp5.py # two time series have unequal length
```


All results are saved in result/*.pkl. You can load them by pickle.

```
with open('XXX.pkl', 'rb') as file:
     data = pickle.load(file)
```